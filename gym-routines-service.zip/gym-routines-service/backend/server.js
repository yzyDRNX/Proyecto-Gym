const express = require('express');
const mysql = require('mysql');
const cors = require('cors');
const app = express();

app.use(cors());
app.use(express.json());

const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'EFRAIN12',
    database: 'gymdb'
});

db.connect(err => {
    if (err) throw err;
    console.log('MySQL connected...');
});

app.get('/routines', (req, res) => {
    db.query('SELECT * FROM routines', (err, result) => {
        if (err) return res.send(err);
        res.json(result);
    });
});

app.post('/routines', (req, res) => {
    const { name, duration } = req.body;
    db.query('INSERT INTO routines (name, duration) VALUES (?, ?)', [name, duration], (err) => {
        if (err) return res.send(err);
        res.json({ message: 'Routine added' });
    });
});

app.put('/routines/:id', (req, res) => {
    const { id } = req.params;
    const { name, duration } = req.body;
    db.query('UPDATE routines SET name = ?, duration = ? WHERE id = ?', [name, duration, id], (err) => {
        if (err) return res.send(err);
        res.json({ message: 'Routine updated' });
    });
});

app.delete('/routines/:id', (req, res) => {
    const { id } = req.params;
    db.query('DELETE FROM routines WHERE id = ?', [id], (err) => {
        if (err) return res.send(err);
        res.json({ message: 'Routine deleted' });
    });
});

app.listen(3000, () => {
    console.log('Server running on port 3000');
});
